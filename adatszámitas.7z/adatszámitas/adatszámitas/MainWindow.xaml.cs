﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace adatszámitas
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        
        private void btn_Click(object sender, RoutedEventArgs e)
        {



       
            //terrabites osztás

            if (cbmérték.Text == "TB" && cbseb.Text == "TB/s")
            {
                double eredmeny = Convert.ToDouble(tbKapacitas.Text) / Convert.ToDouble(sld.Value);

                double orak = Math.Floor(eredmeny / 3600);
                eredmeny %= 3600;
                double percek = Math.Floor(eredmeny / 60);
                double maradekMasodpercek = eredmeny % 60;
                 atvlbl.Content = ($"Eredmény: {orak} óra, {percek} perc, {maradekMasodpercek} másodperc");


            }
            if (cbmérték.Text == "TB" && cbseb.Text == "GB/s")
            {
                double eredmeny = Convert.ToDouble(tbKapacitas.Text)  / (Convert.ToDouble(sld.Value)/1000);
           

                double orak = Math.Floor(eredmeny / 3600);
                eredmeny %= 3600;
                double percek = Math.Floor(eredmeny / 60);
                double maradekMasodpercek = eredmeny % 60;
                atvlbl.Content = ($"Eredmény: {orak} óra, {percek} perc, {maradekMasodpercek} másodperc");
            }
            if (cbmérték.Text == "TB" && cbseb.Text == "MB/s")
            {
                double eredmeny = Convert.ToDouble(tbKapacitas.Text) / (Convert.ToDouble(sld.Value) / 1000000);
              
                double orak = Math.Floor(eredmeny / 3600);
                eredmeny %= 3600;
                double percek = Math.Floor(eredmeny / 60);
                double maradekMasodpercek = eredmeny % 60;
                atvlbl.Content = ($"Eredmény: {orak} óra, {percek} perc, {maradekMasodpercek} másodperc");
            }
            if (cbmérték.Text == "TB" && cbseb.Text == "KB/s")
            {
                double eredmeny = Convert.ToDouble(tbKapacitas.Text) / (Convert.ToDouble(sld.Value) / 1000000000);
               

                double orak = Math.Floor(eredmeny / 3600);
                eredmeny %= 3600;
                double percek = Math.Floor(eredmeny / 60);
                double maradekMasodpercek = eredmeny % 60;
                atvlbl.Content = ($"Eredmény: {orak} óra, {percek} perc, {maradekMasodpercek} másodperc");
            }


            //gigabites osztás

            if (cbmérték.Text == "GB" && cbseb.Text == "TB/s")
            {
                double eredmeny = Convert.ToDouble(tbKapacitas.Text) / (Convert.ToDouble(sld.Value) * 1000);
             

                double orak = Math.Floor(eredmeny / 3600);
                eredmeny %= 3600;
                double percek = Math.Floor(eredmeny / 60);
                double maradekMasodpercek = eredmeny % 60;
                atvlbl.Content = ($"Eredmény: {orak} óra, {percek} perc, {maradekMasodpercek} másodperc");
            }
            if (cbmérték.Text == "GB" && cbseb.Text == "GB/s")
            {
                double eredmeny = Convert.ToDouble(tbKapacitas.Text) / Convert.ToDouble(sld.Value);

                double orak = Math.Floor(eredmeny / 3600);
                eredmeny %= 3600;
                double percek = Math.Floor(eredmeny / 60);
                double maradekMasodpercek = eredmeny % 60;
                atvlbl.Content = ($"Eredmény: {orak} óra, {percek} perc, {maradekMasodpercek} másodperc");
            }
            if (cbmérték.Text == "GB" && cbseb.Text == "MB/s")
            {
                double eredmeny = Convert.ToDouble(tbKapacitas.Text) / (Convert.ToDouble(sld.Value) / 1000);

                double orak = Math.Floor(eredmeny / 3600);
                eredmeny %= 3600;
                double percek = Math.Floor(eredmeny / 60);
                double maradekMasodpercek = eredmeny % 60;
                atvlbl.Content = ($"Eredmény: {orak} óra, {percek} perc, {maradekMasodpercek} másodperc");
            }
            if (cbmérték.Text == "GB" && cbseb.Text == "KB/s")
            {
                double eredmeny = Convert.ToDouble(tbKapacitas.Text) / (Convert.ToDouble(sld.Value) / 1000000);

                double orak = Math.Floor(eredmeny / 3600);
                eredmeny %= 3600;
                double percek = Math.Floor(eredmeny / 60);
                double maradekMasodpercek = eredmeny % 60;
                atvlbl.Content = ($"Eredmény: {orak} óra, {percek} perc, {maradekMasodpercek} másodperc");
            }

            //megabites osztás

            if (cbmérték.Text == "MB" && cbseb.Text == "TB/s")
            {
                double eredmeny = Convert.ToDouble(tbKapacitas.Text) / (Convert.ToDouble(sld.Value) * 1000000);

                double orak = Math.Floor(eredmeny / 3600);
                eredmeny %= 3600;
                double percek = Math.Floor(eredmeny / 60);
                double maradekMasodpercek = eredmeny % 60;
                atvlbl.Content = ($"Eredmény: {orak} óra, {percek} perc, {maradekMasodpercek} másodperc");
            }
            if (cbmérték.Text == "MB" && cbseb.Text == "GB/s")
            {
                double eredmeny = Convert.ToDouble(tbKapacitas.Text) / (Convert.ToDouble(sld.Value) * 1000);

                double orak = Math.Floor(eredmeny / 3600);
                eredmeny %= 3600;
                double percek = Math.Floor(eredmeny / 60);
                double maradekMasodpercek = eredmeny % 60;
                atvlbl.Content = ($"Eredmény: {orak} óra, {percek} perc, {maradekMasodpercek} másodperc");
            }
            if (cbmérték.Text == "MB" && cbseb.Text == "MB/s")
            {
                double eredmeny = Convert.ToDouble(tbKapacitas.Text) / Convert.ToDouble(sld.Value);

                double orak = Math.Floor(eredmeny / 3600);
                eredmeny %= 3600;
                double percek = Math.Floor(eredmeny / 60);
                double maradekMasodpercek = eredmeny % 60;
                atvlbl.Content = ($"Eredmény: {orak} óra, {percek} perc, {maradekMasodpercek} másodperc");
            }
            if (cbmérték.Text == "MB" && cbseb.Text == "KB/s")
            {
                double eredmeny = Convert.ToDouble(tbKapacitas.Text) / (Convert.ToDouble(sld.Value) / 1000);

                double orak = Math.Floor(eredmeny / 3600);
                eredmeny %= 3600;
                double percek = Math.Floor(eredmeny / 60);
                double maradekMasodpercek = eredmeny % 60;
                atvlbl.Content = ($"Eredmény: {orak} óra, {percek} perc, {maradekMasodpercek} másodperc");
            }

            //kilobites osztás

            if (cbmérték.Text == "KB" && cbseb.Text == "TB/s")
            {
                double eredmeny = Convert.ToDouble(tbKapacitas.Text) / (Convert.ToDouble(sld.Value) * 1000000000);

                double orak = Math.Floor(eredmeny / 3600);
                eredmeny %= 3600;
                double percek = Math.Floor(eredmeny / 60);
                double maradekMasodpercek = eredmeny % 60;
                atvlbl.Content = ($"Eredmény: {orak} óra, {percek} perc, {maradekMasodpercek} másodperc");
            }
            if (cbmérték.Text == "KB" && cbseb.Text == "GB/s")
            {
                double eredmeny = Convert.ToDouble(tbKapacitas.Text) / (Convert.ToDouble(sld.Value) * 1000000);

                double orak = Math.Floor(eredmeny / 3600);
                eredmeny %= 3600;
                double percek = Math.Floor(eredmeny / 60);
                double maradekMasodpercek = eredmeny % 60;
                atvlbl.Content = ($"Eredmény: {orak} óra, {percek} perc, {maradekMasodpercek} másodperc");
            }
            if (cbmérték.Text == "KB" && cbseb.Text == "MB/s")
            {
                double eredmeny = Convert.ToDouble(tbKapacitas.Text) / (Convert.ToDouble(sld.Value) * 1000);

                double orak = Math.Floor(eredmeny / 3600);
                eredmeny %= 3600;
                double percek = Math.Floor(eredmeny / 60);
                double maradekMasodpercek = eredmeny % 60;
                atvlbl.Content = ($"Eredmény: {orak} óra, {percek} perc, {maradekMasodpercek} másodperc");
            }
            if (cbmérték.Text == "KB" && cbseb.Text == "KB/s")
            {
                double eredmeny = Convert.ToDouble(tbKapacitas.Text) / Convert.ToDouble(sld.Value);

                double orak = Math.Floor(eredmeny / 3600);
                eredmeny %= 3600;
                double percek = Math.Floor(eredmeny / 60);
                double maradekMasodpercek = eredmeny % 60;
                atvlbl.Content = ($"Eredmény: {orak} óra, {percek} perc, {maradekMasodpercek} másodperc");
            }

         
        }
       
        private void sld_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            sldlabel.Content = sld.Value.ToString();
        }
    }
}
